package org.os.lms.api.contoroller;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.os.lms.api.controller.QuizController;
import org.os.lms.api.model.Question;
import org.os.lms.api.model.Quiz;
import org.os.lms.service.QuizService;
import java.util.Arrays;
import java.util.List;

@ExtendWith(MockitoExtension.class)
public class QuizControllerTest {

    @Mock
    private QuizService quizService;

    @InjectMocks
    private QuizController quizController;
    private Quiz quiz;
    private Question question;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this); // Initialize mocks

        // Create a sample quiz to return in the test
        quiz = new Quiz();
        quiz.setId(1);
        quiz.setTitle("Sample Quiz");
    }
    @Test
    public void testGetQuizById() {
        // Make the mock quizService return the sample quiz when called with ID 1
        when(quizService.getQuizById(1)).thenReturn(quiz);

        // Call the controller method
        Quiz foundQuiz = quizController.getQuizById(1);

        // Check that the returned quiz is not null
        assertNotNull(foundQuiz);
        // Check that the quiz ID is 1
        assertEquals(1, foundQuiz.getId());
        // Verify that the quizService method was called exactly once
        verify(quizService, times(1)).getQuizById(1);
    }

    @Test
    public void testCreateQuiz() {
        when(quizService.createQuiz(anyString(), anyInt(), anyInt(), anyList())).thenReturn(quiz);

        Quiz createdQuiz = quizController.createQuiz("Sample Quiz", 1, 101, Arrays.asList(question));

        assertNotNull(createdQuiz);
        assertEquals("Sample Quiz", createdQuiz.getTitle());
        assertEquals(1, createdQuiz.getId());
        verify(quizService, times(1)).createQuiz(anyString(), anyInt(), anyInt(), anyList());
    }



    @Test
    public void testGenerateRandomQuiz() {
        // Simulate the behavior of quizService.generateRandomQuiz when called
        when(quizService.generateRandomQuiz(101, 5)).thenReturn(quiz);
        Quiz generatedQuiz = quizController.generateRandomQuiz(101, 5);
        assertNotNull(generatedQuiz);
        verify(quizService, times(1)).generateRandomQuiz(101, 5);
    }

    @Test
    public void testAddQuestionToBank() {
        //no return value is expected , the mock just does nothing.
        doNothing().when(quizService).addQuestionToBank(101, question);

        String response = quizController.addQuestionToBank(101, question);

        assertEquals("Question added to course 101", response);
        verify(quizService, times(1)).addQuestionToBank(101, question);
    }

    @Test
    public void testGetQuestionBank() {
        when(quizService.getQuestionBank(101)).thenReturn(Arrays.asList(question));

        List<Question> questions = quizController.getQuestionBank(101);

        assertNotNull(questions);
        assertFalse(questions.isEmpty());
        verify(quizService, times(1)).getQuestionBank(101);
    }

}
