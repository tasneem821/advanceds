package org.os.lms.api.controller;
import org.os.lms.api.model.Question;
import org.os.lms.api.model.Quiz;
import org.os.lms.api.model.Student;
import org.os.lms.api.model.gradeQuizRequest;
import org.os.lms.service.QuizService;
import org.os.lms.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.ResponseEntity;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/quizzes")
public class QuizController {

    @Autowired
    private QuizService quizService;
    @Autowired
    private StudentService studentService;

    // Create a new quiz
    @PostMapping("/create")
    public Quiz createQuiz(@RequestParam String title, @RequestParam int quizId, @RequestParam int courseId, @RequestBody List<Question> questions) {
        return quizService.createQuiz(title,quizId, courseId, questions);
    }

    // Get a quiz by ID
    @GetMapping("/{quizId}")
    public Quiz getQuizById(@PathVariable int quizId) {
        return quizService.getQuizById(quizId);
    }

    @PostMapping("/generate")
    public Quiz generateRandomQuiz(@RequestParam int courseId, @RequestParam int totalQuestionCount) {
        if (totalQuestionCount < 0) {
            throw new IllegalArgumentException("Total question count cannot be negative.");
        }
        return quizService.generateRandomQuiz(courseId, totalQuestionCount);
    }

    // Add a question to a question bank
    @PostMapping("/questions/add")
    public String addQuestionToBank(@RequestParam int courseId, @RequestBody Question question) {
        quizService.addQuestionToBank(courseId, question);
        return "Question added to course " + courseId;
    }

    // Get all questions for a specific course
    @GetMapping("/questions/{courseId}")
    public List<Question> getQuestionBank(@PathVariable int courseId) {
        return quizService.getQuestionBank(courseId);
    }

    @PostMapping("/grade/{quizId}")
    public ResponseEntity<String> gradeQuiz(@PathVariable int quizId, @RequestBody gradeQuizRequest request) {
        try {
            String feedback = quizService.gradeQuiz(request, quizId);
            return ResponseEntity.ok(feedback);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("An error occurred: " + e.getMessage());
        }
    }

    // get the quiz scores of a student by ID
    @GetMapping("/scores/{studentId}")
    public Map<Integer, Integer> getStudentQuizScores(@PathVariable int studentId) {
        Student student = studentService.getStudent(studentId);
        if (student != null) {
            return quizService.getStudentQuizScores(student);
        }
        return null;
    }

}