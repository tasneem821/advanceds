package org.os.lms.service;
import org.os.lms.api.model.Question;
import org.os.lms.api.model.Quiz;
import org.os.lms.api.model.Student;
import org.os.lms.api.model.gradeQuizRequest;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.*;

@Service
public class QuizService {
    private Map<Integer, Quiz> quizzes = new HashMap<>();
    private Map<Integer, List<Question>> questionBanks = new HashMap<>(); // Question banks per course
    private int quizId;
    private int quizIdCounter=1;
    private int questionIdCounter = 1;

    public QuizService() {
        // Quiz 1: Agile & Scrum Quiz
        List<Question> softwareQuestionsQuiz = new ArrayList<>();
        softwareQuestionsQuiz.add(createQuestion("What is Agile methodology?", "SHORT_ANSWER", null, "A set of principles for software development"));
        softwareQuestionsQuiz.add(createQuestion("What is Scrum?", "MCQ", new String[]{"Agile", "Waterfall", "Spiral", "V-Model"}, "Agile"));
        quizzes.put(1, createQuiz("Agile & Scrum Quiz", 1,1, softwareQuestionsQuiz));
        // Quiz 2: Database Fundamentals Quiz
        List<Question> databaseQuestionsQuiz = new ArrayList<>();
        databaseQuestionsQuiz.add(createQuestion("What is a primary key?", "SHORT_ANSWER", null, "A unique identifier for a database record"));
        databaseQuestionsQuiz.add(createQuestion("What is SQL?", "MCQ", new String[]{"Structured Query Language", "System Query Language", "Simple Query Language"}, "Structured Query Language"));
        quizzes.put(2, createQuiz("Database Fundamentals Quiz", 2,2, databaseQuestionsQuiz));
        // Quiz 3: Spring Framework Quiz
        List<Question> springQuestions = new ArrayList<>();
        springQuestions.add(createQuestion("What is Spring Framework?", "SHORT_ANSWER", null, "A framework for building Java-based enterprise applications"));
        springQuestions.add(createQuestion("What is Spring Boot?", "MCQ", new String[]{"A framework", "A library", "A programming language"}, "A framework"));
        quizzes.put(3, createQuiz("Spring Framework Quiz", 3,3, springQuestions));
        // Quiz 4: Microservices Architecture Quiz
        List<Question> microservicesQuestions = new ArrayList<>();
        microservicesQuestions.add(createQuestion("What is Microservices Architecture?", "SHORT_ANSWER", null, "An architectural style that structures an application as a collection of loosely coupled services"));
        microservicesQuestions.add(createQuestion("What is a microservice?", "MCQ", new String[]{"A database system", "A single service in a microservices architecture", "A communication protocol"}, "A single service in a microservices architecture"));
        quizzes.put(4, createQuiz("Microservices Architecture Quiz", 4,4, microservicesQuestions));
        // Adding data manually to the question bank
        // Software Engineering Course (ID: 1)
        List<Question> softwareQuestions = new ArrayList<>();
        softwareQuestions.add(createQuestion("What is Agile methodology?", "SHORT_ANSWER", null, "A set of principles for software development"));
        softwareQuestions.add(createQuestion("Scrum is a framework of which methodology?", "MCQ", new String[]{"Waterfall", "Agile", "Spiral", "V-Model"}, "Agile"));
        softwareQuestions.add(createQuestion("True or False: Kanban is an iterative process.", "TRUE_FALSE", null, "False"));
        softwareQuestions.add(createQuestion("What is the Singleton design pattern?", "SHORT_ANSWER", null, "A pattern ensuring only one instance of a class exists."));
        softwareQuestions.add(createQuestion("Which pattern ensures a group of related objects are created?", "MCQ", new String[]{"Singleton", "Factory", "Observer", "Prototype"}, "Factory"));
        softwareQuestions.add(createQuestion("True or False: The Decorator pattern adds behavior to an object dynamically.", "TRUE_FALSE", null, "True"));
        softwareQuestions.add(createQuestion("Which pattern defines a skeleton of an algorithm?", "MCQ", new String[]{"Strategy", "Template Method", "Observer", "Factory"}, "Template Method"));
        softwareQuestions.add(createQuestion("What is the Observer pattern used for?", "SHORT_ANSWER", null, "To notify dependent objects when an observable changes."));
        softwareQuestions.add(createQuestion("True or False: The Strategy pattern provides multiple algorithms for the same task.", "TRUE_FALSE", null, "True"));
        softwareQuestions.add(createQuestion("Which design pattern is used to decouple object creation from its usage?", "MCQ", new String[]{"Builder", "Factory", "Singleton", "Observer"}, "Factory"));
        softwareQuestions.add(createQuestion("Explain the Proxy pattern.", "SHORT_ANSWER", null, "A pattern providing a placeholder to control access to an object."));
        softwareQuestions.add(createQuestion("True or False: In the Composite pattern, individual objects and groups of objects are treated the same way.", "TRUE_FALSE", null, "True"));
        softwareQuestions.add(createQuestion("Which pattern is useful for building complex objects step by step?", "MCQ", new String[]{"Prototype", "Builder", "Decorator", "Factory"}, "Builder"));
        softwareQuestions.add(createQuestion("What does @SpringBootApplication annotate?", "MCQ", new String[]{"A service", "A controller", "The main class", "A repository"}, "The main class"));
        softwareQuestions.add(createQuestion("True or False: Spring Boot uses embedded Tomcat by default.", "TRUE_FALSE", null, "True"));
        softwareQuestions.add(createQuestion("What is the purpose of application.properties in Spring Boot?", "SHORT_ANSWER", null, "To configure application settings."));
        softwareQuestions.add(createQuestion("Which annotation is used to expose a RESTful endpoint?", "MCQ", new String[]{"@RestController", "@Service", "@Repository", "@Component"}, "@RestController"));
        softwareQuestions.add(createQuestion("True or False: Spring Boot eliminates the need for XML configuration.", "TRUE_FALSE", null, "True"));
        softwareQuestions.add(createQuestion("What is the purpose of @Autowired in Spring Boot?", "SHORT_ANSWER", null, "To perform dependency injection."));
        softwareQuestions.add(createQuestion("Which dependency adds Spring Boot's Actuator features?", "MCQ", new String[]{"spring-boot-starter-web", "spring-boot-starter-data-jpa", "spring-boot-starter-actuator", "spring-boot-starter-security"}, "spring-boot-starter-actuator"));
        softwareQuestions.add(createQuestion("True or False: @RequestParam maps a query parameter to a method parameter.", "TRUE_FALSE", null, "True"));
        softwareQuestions.add(createQuestion("What does the @Transactional annotation do?", "SHORT_ANSWER", null, "It ensures that database operations are wrapped in a transaction."));
        softwareQuestions.add(createQuestion("Which feature of Spring Boot is used for caching?", "MCQ", new String[]{"@Cacheable", "@RestController", "@Scheduled", "@Repository"}, "@Cacheable"));
        softwareQuestions.add(createQuestion("Which pattern is designed for separating concerns into three interconnected components?", "MCQ", new String[]{"MVVM", "MVC", "Layered", "Event-driven"}, "MVC"));
        softwareQuestions.add(createQuestion("True or False: Microservices architecture consists of tightly coupled services.", "TRUE_FALSE", null, "False"));
        softwareQuestions.add(createQuestion("What is the main principle of a Layered Architecture?", "SHORT_ANSWER", null, "Separation of concerns into distinct layers."));
        softwareQuestions.add(createQuestion("Which architecture pattern is most suitable for real-time applications?", "MCQ", new String[]{"Layered", "Event-driven", "Microservices", "Monolithic"}, "Event-driven"));
        softwareQuestions.add(createQuestion("True or False: In a Monolithic architecture, all components are deployed together.", "TRUE_FALSE", null, "True"));
        softwareQuestions.add(createQuestion("What is Domain-Driven Design?", "SHORT_ANSWER", null, "A design approach that focuses on the core domain and domain logic."));
        softwareQuestions.add(createQuestion("Which architecture is characterized by independent, deployable services?", "MCQ", new String[]{"Monolithic", "Microservices", "Event-driven", "Serverless"}, "Microservices"));
        softwareQuestions.add(createQuestion("True or False: Serverless architecture eliminates the need for infrastructure management.", "TRUE_FALSE", null, "True"));
        softwareQuestions.add(createQuestion("Explain the purpose of CQRS.", "SHORT_ANSWER", null, "CQRS separates read and write operations for scalability and performance."));
        softwareQuestions.add(createQuestion("Which pattern is commonly used in Microservices for communication between services?", "MCQ", new String[]{"Repository", "Event-driven", "Mediator", "Factory"}, "Event-driven"));

        questionBanks.put(1, softwareQuestions);

        // Database Course (ID: 2)
        List<Question> databaseQuestions = new ArrayList<>();
        databaseQuestions.add(createQuestion("What is a primary key?", "SHORT_ANSWER", null, "A unique identifier for a database record"));
        databaseQuestions.add(createQuestion("Which SQL statement is used to fetch data?", "MCQ", new String[]{"INSERT", "UPDATE", "SELECT", "DELETE"}, "SELECT"));
        databaseQuestions.add(createQuestion("True or False: A foreign key can reference multiple tables.", "TRUE_FALSE", null, "False"));
        databaseQuestions.add(createQuestion("What is an index in a database?", "SHORT_ANSWER", null, "A data structure that improves the speed of data retrieval"));
        databaseQuestions.add(createQuestion("Which SQL keyword is used to sort data?", "MCQ", new String[]{"ORDER BY", "GROUP BY", "HAVING", "SORT"}, "ORDER BY"));
        databaseQuestions.add(createQuestion("True or False: Indexes always speed up data insertion.", "TRUE_FALSE", null, "False"));
        databaseQuestions.add(createQuestion("What is the difference between UNIQUE and PRIMARY KEY?", "SHORT_ANSWER", null, "PRIMARY KEY uniquely identifies a row, and UNIQUE ensures unique values in a column"));
        databaseQuestions.add(createQuestion("Which type of index supports faster text search?", "MCQ", new String[]{"Clustered Index", "Non-clustered Index", "Full-Text Index", "Unique Index"}, "Full-Text Index"));
        databaseQuestions.add(createQuestion("True or False: A clustered index changes the physical order of data in the table.", "TRUE_FALSE", null, "True"));
        databaseQuestions.add(createQuestion("What does the COUNT() function do?", "SHORT_ANSWER", null, "It returns the number of rows matching a query condition"));
        databaseQuestions.add(createQuestion("Which clause is used to filter rows in a SELECT statement?", "MCQ", new String[]{"WHERE", "GROUP BY", "HAVING", "ORDER BY"}, "WHERE"));
        databaseQuestions.add(createQuestion("True or False: A composite index can be created on multiple columns.", "TRUE_FALSE", null, "True"));
        databaseQuestions.add(createQuestion("What is the purpose of the HAVING clause?", "SHORT_ANSWER", null, "To filter grouped data after aggregation"));
        databaseQuestions.add(createQuestion("Which SQL command is used to add an index to a table?", "MCQ", new String[]{"ALTER TABLE", "CREATE INDEX", "ADD INDEX", "MODIFY INDEX"}, "CREATE INDEX"));
        databaseQuestions.add(createQuestion("True or False: A database table can have only one clustered index.", "TRUE_FALSE", null, "True"));
        databaseQuestions.add(createQuestion("What is the purpose of a foreign key?", "SHORT_ANSWER", null, "To maintain referential integrity between tables"));
        databaseQuestions.add(createQuestion("Which index type is typically faster for range queries?", "MCQ", new String[]{"Clustered Index", "Non-clustered Index", "Full-Text Index", "Hash Index"}, "Clustered Index"));
        databaseQuestions.add(createQuestion("True or False: DROP INDEX removes an index from the table.", "TRUE_FALSE", null, "True"));
        databaseQuestions.add(createQuestion("What is the difference between DELETE and TRUNCATE?", "SHORT_ANSWER", null, "DELETE removes rows with conditions, TRUNCATE removes all rows quickly without logging each row"));
        databaseQuestions.add(createQuestion("Which SQL function calculates the average of a column?", "MCQ", new String[]{"SUM()", "COUNT()", "AVG()", "MAX()"}, "AVG()"));
        databaseQuestions.add(createQuestion("True or False: UNIQUE and PRIMARY KEY constraints both enforce uniqueness.", "TRUE_FALSE", null, "True"));
        databaseQuestions.add(createQuestion("What is a composite key?", "SHORT_ANSWER", null, "A key composed of two or more columns to uniquely identify a row"));
        databaseQuestions.add(createQuestion("Which SQL clause is used for grouping rows?", "MCQ", new String[]{"GROUP BY", "ORDER BY", "HAVING", "WHERE"}, "GROUP BY"));
        databaseQuestions.add(createQuestion("True or False: Indexes can improve query performance for large datasets.", "TRUE_FALSE", null, "True"));
        databaseQuestions.add(createQuestion("What does the DISTINCT keyword do?", "SHORT_ANSWER", null, "It removes duplicate rows from the result set"));
        databaseQuestions.add(createQuestion("Which index is automatically created with a PRIMARY KEY?", "MCQ", new String[]{"Clustered Index", "Non-clustered Index", "Full-Text Index", "Hash Index"}, "Clustered Index"));
        databaseQuestions.add(createQuestion("True or False: Non-clustered indexes do not alter the table's physical order.", "TRUE_FALSE", null, "True"));
        databaseQuestions.add(createQuestion("What is normalization?", "SHORT_ANSWER", null, "A process to reduce redundancy and improve data integrity"));
        databaseQuestions.add(createQuestion("Which SQL operator is used to compare patterns?", "MCQ", new String[]{"LIKE", "BETWEEN", "IN", "EXISTS"}, "LIKE"));
        databaseQuestions.add(createQuestion("True or False: An index on frequently updated columns can lead to performance issues.", "TRUE_FALSE", null, "True"));
        questionBanks.put(2, databaseQuestions);
    }

    private Question createQuestion(String text, String type, String[] options, String answer) {
        Question question = new Question();
        question.setId(questionIdCounter++);
        question.setText(text);
        question.setType(type);
        question.setOptions(options);
        question.setAnswer(answer);
        return question;
    }

    public void addQuestionToBank(int courseId, Question question) {
        question.setId(questionIdCounter++);
        questionBanks.putIfAbsent(courseId, new ArrayList<>());
        questionBanks.get(courseId).add(question);
    }

    public List<Question> getQuestionBank(int courseId) {
        return questionBanks.getOrDefault(courseId, new ArrayList<>());
    }

    public Quiz createQuiz(String title,int quizId, int courseId, List<Question> questions) {
        Quiz quiz = new Quiz(quizId, title,courseId);
        quiz.setId(quizId);
        quiz.setTitle(title);
        quiz.setCourseId(courseId);
        quiz.setQuestions(questions);
        quizzes.put(quiz.getId(), quiz);
        return quiz;
    }

    public Quiz getQuizById(int quizId) {
        return quizzes.get(quizId);
    }

    public Quiz generateRandomQuiz(int courseId, int totalQuestionCount) {
        // Get the question bank for the course
        List<Question> questionBank = getQuestionBank(courseId);
        // Separate the questions by type
        List<Question> mcqQuestions = new ArrayList<>();
        List<Question> trueFalseQuestions = new ArrayList<>();
        List<Question> shortAnswerQuestions = new ArrayList<>();
        for (Question question : questionBank) {
            switch (question.getType()) {
                case "MCQ":
                    mcqQuestions.add(question);
                    break;
                case "TRUE_FALSE":
                    trueFalseQuestions.add(question);
                    break;
                case "SHORT_ANSWER":
                    shortAnswerQuestions.add(question);
                    break;
            }
        }

        // Shuffle the lists to randomize the order of questions
        Collections.shuffle(mcqQuestions);
        Collections.shuffle(trueFalseQuestions);
        Collections.shuffle(shortAnswerQuestions);

        // Initialize the list of selected questions
        List<Question> selectedQuestions = new ArrayList<>();

        // Randomly determine the number of questions from each type
        int remainingQuestions = totalQuestionCount;

        // Distribute the questions randomly
        while (remainingQuestions > 0) {
            // Randomly pick a question type (MCQ, TRUE_FALSE, SHORT_ANSWER)
            int randomTypeIndex = new Random().nextInt(3); // Random number between 0 and 2
            switch (randomTypeIndex) {
                case 0: // MCQ
                    if (!mcqQuestions.isEmpty()) {
                        selectedQuestions.add(mcqQuestions.remove(0)); // Add and remove
                        remainingQuestions--;
                    }
                    break;
                case 1: // TRUE_FALSE
                    if (!trueFalseQuestions.isEmpty()) {
                        selectedQuestions.add(trueFalseQuestions.remove(0)); // Add and remove
                        remainingQuestions--;
                    }
                    break;
                case 2: // SHORT_ANSWER
                    if (!shortAnswerQuestions.isEmpty()) {
                        selectedQuestions.add(shortAnswerQuestions.remove(0)); // Add and remove
                        remainingQuestions--;
                    }
                    break;
            }
        }

        // Return the generated quiz with the selected questions
        return createQuiz("Random Quiz", quizIdCounter++, courseId, selectedQuestions);
    }


    public String gradeQuiz(gradeQuizRequest request, int quizId) {
        Quiz quiz = quizzes.get(quizId);
        if (quiz == null) {
            return "Quiz not found.";
        }
        int id= request.getId();
        StudentServiceImpl s=new StudentServiceImpl();
        Student s1=s.getStudent(id);
        if (s1 == null) {
            return "Student not exist in the database.";
        }
        Student student = new Student();
        student.setId(request.getId());
        student.setName(request.getName());
        student.setQuizScores(new HashMap<>());
        Map<Integer, String> studentAnswers = request.getAnswers();
        List<Question> questions = quiz.getQuestions();
        StringBuilder feedback = new StringBuilder();
        int correctAnswers = 0;
        for (Question question : questions) {
            String studentAnswer = studentAnswers.get(question.getId());
            String correctAnswer = question.getAnswer();

            if (studentAnswer == null) {
                feedback.append("Question ").append(question.getId()).append(": No answer provided.\n");
            } else if (studentAnswer.equalsIgnoreCase(correctAnswer)) {
                feedback.append("Question ").append(question.getId()).append(": Correct!\n");
                correctAnswers++;
            } else {
                feedback.append("Question ").append(question.getId()).append(": Incorrect. Correct answer is: ")
                        .append(correctAnswer).append("\n");
            }
        }

        int totalQuestions = questions.size();
        int grade = (correctAnswers * 100) / totalQuestions;
        Map<Integer, Integer> quizScoress = new HashMap<>();
        quizScoress.put(id, grade);
        s1.setQuizScores(quizScoress);

        feedback.append("\nTotal correct answers: ").append(correctAnswers).append(" out of ").append(totalQuestions);
        feedback.append("\nGrade: ").append(grade).append("%");
        feedback.append("\nStudent Name: ").append(student.getName());
        feedback.append("\nStudent ID: ").append(student.getId());

        return feedback.toString();
    }

    public Map<Integer, Integer> getStudentQuizScores(Student student) {
        return student.getQuizScores(); // Map of quizId to scores
    }
}