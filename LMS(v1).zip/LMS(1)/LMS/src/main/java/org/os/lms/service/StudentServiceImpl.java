package org.os.lms.service;

import org.os.lms.api.model.Student;
import org.springframework.stereotype.Service;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Service
public class StudentServiceImpl implements StudentService {

    private final List<Student> students = new ArrayList<>();

    public StudentServiceImpl() {
        // Manually adding 50 students with quiz and assignment scores
        students.add(new Student(1, "Nada Mohammed", new HashMap<>() {{
            put(1, 100);
            put(2, 9);
            put(3, 7);
        }}, new ArrayList<>() {{
            add(19);
            add(18);
            add(20);
        }}));

        students.add(new Student(2, "Fatima Al-Fahad", new HashMap<>() {{
            put(1, 9); // Quiz 1 score out of 10
            put(2, 8); // Quiz 2 score out of 10
            put(3, 9); // Quiz 3 score out of 10
        }}, new ArrayList<>() {{
            add(19);
            add(18);
            add(20);
        }}));

        students.add(new Student(3, "Mohammed Al-Sayed", new HashMap<>() {{
            put(1, 7); // Quiz 1 score out of 10
            put(2, 8); // Quiz 2 score out of 10
            put(3, 8); // Quiz 3 score out of 10
        }}, new ArrayList<>() {{
            add(19);
            add(18);
            add(20);
        }}));

        students.add(new Student(4, "Aisha Zain", new HashMap<>() {{
            put(1, 8); // Quiz 1 score out of 10
            put(2, 9); // Quiz 2 score out of 10
            put(3, 9); // Quiz 3 score out of 10
        }}, new ArrayList<>() {{
            add(19);
            add(18);
            add(20);
        }}));

        students.add(new Student(5, "Omar Ibrahim", new HashMap<>() {{
            put(1, 6); // Quiz 1 score out of 10
            put(2, 7); // Quiz 2 score out of 10
            put(3, 7); // Quiz 3 score out of 10
        }}, new ArrayList<>() {{
            add(19);
            add(18);
            add(20);
        }}));

        students.add(new Student(6, "Layla Khaled", new HashMap<>() {{
            put(1, 9); // Quiz 1 score out of 10
            put(2, 10); // Quiz 2 score out of 10
            put(3, 8); // Quiz 3 score out of 10
        }}, new ArrayList<>() {{
            add(19);
            add(18);
            add(20);
        }}));

        students.add(new Student(7, "Youssef Rahman", new HashMap<>() {{
            put(1, 7); // Quiz 1 score out of 10
            put(2, 6); // Quiz 2 score out of 10
            put(3, 8); // Quiz 3 score out of 10
        }}, new ArrayList<>() {{
            add(19);
            add(18);
            add(20);
        }}));

        students.add(new Student(8, "Zaynab Mustafa", new HashMap<>() {{
            put(1, 10); // Quiz 1 score out of 10
            put(2, 8); // Quiz 2 score out of 10
            put(3, 9); // Quiz 3 score out of 10
        }}, new ArrayList<>() {{
            add(19);
            add(18);
            add(20);
        }}));

        students.add(new Student(9, "Hassan Ali", new HashMap<>() {{
            put(1, 6); // Quiz 1 score out of 10
            put(2, 5); // Quiz 2 score out of 10
            put(3, 7); // Quiz 3 score out of 10
        }}, new ArrayList<>() {{
            add(19);
            add(18);
            add(20);
        }}));

        students.add(new Student(10, "Mariam Hassan", new HashMap<>() {{
            put(1, 9); // Quiz 1 score out of 10
            put(2, 7); // Quiz 2 score out of 10
            put(3, 9);
        }}, new ArrayList<>() {{
            add(19);
            add(18);
            add(20);
        }}));


    }

    @Override
    public boolean addStudent(Student student) {
        for (Student existingStudent : students) {
            if (existingStudent.getId() == student.getId()) {
                return false; // Duplicate ID
            }
        }
        return students.add(student);
    }

    @Override
    public Student getStudent(int id) {
        return students.stream()
                .filter(student -> student.getId() == id)
                .findFirst()
                .orElse(null);
    }

    @Override
    public List<Student> getAllStudents() {
        return new ArrayList<>(students);
    }

    @Override
    public boolean updateStudentQuizScore(int studentId, int quizId, int score) {
        Student student = getStudent(studentId);
        if (student == null) {
            return false; // Student not found
        }
        student.getQuizScores().put(quizId, score);
        return true;
    }

    @Override
    public boolean addAssignmentToStudent(int studentId, int assignmentId) {
        Student student = getStudent(studentId);
        if (student == null) {
            return false; // Student not found
        }
        student.getAssignmentIds().add(assignmentId);
        return true;
    }
}
