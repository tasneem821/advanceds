package org.os.lms.api.model;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Question {
    private int id;
    @JsonProperty("questionText")
    private String text;
    @JsonProperty("questionType")
    private String type;
    @JsonProperty("options")
    private String[] options; // For MCQ
    @JsonProperty("correctAnswer")
    private String answer; // Correct answer

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String[] getOptions() {
        return options;
    }

    public void setOptions(String[] options) {
        this.options = options;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }
}