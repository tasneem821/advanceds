package org.os.lms;
import org.os.lms.api.model.Student;
import org.os.lms.api.model.Response;
import org.os.lms.service.StudentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/student")
public class StudentController {

    private final StudentService studentService;
    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }
    @PostMapping()
    public Response addStudent(@RequestBody Student student) {
        boolean result = studentService.addStudent(student);
        Response response = new Response();
        response.setStatus(result);
        response.setMessage(result ? "Student added successfully" : "Student with this ID already exists");
        return response;
    }

    @GetMapping("/{id}")
    public Student getStudent(@PathVariable int id) {
        return studentService.getStudent(id);
    }

    @GetMapping("/all")
    public List<Student> getAllStudents() {
        return studentService.getAllStudents();
    }

    @PostMapping("/{id}/addQuizScore")
    public Response addQuizScore(@PathVariable int id, @RequestParam int score) {
        boolean result = studentService.updateStudentQuizScore(id, score);
        Response response = new Response();
        response.setStatus(result);
        response.setMessage(result ? "Score added successfully" : "Student not found");
        return response;
    }

    @PostMapping("/{id}/addAssignment")
    public Response addAssignment(@PathVariable int id, @RequestParam int assignmentId) {
        boolean result = studentService.addAssignmentToStudent(id, assignmentId);
        Response response = new Response();
        response.setStatus(result);
        response.setMessage(result ? "Assignment added successfully" : "Student not found");
        return response;
    }
}
