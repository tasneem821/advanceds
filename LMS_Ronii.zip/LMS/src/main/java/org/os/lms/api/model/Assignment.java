package org.os.lms.api.model;

public class Assignment {
    private int id; // Assignment ID
    private int studentId; // ID of the student who submitted the assignment
    private String fileName; // Name of the uploaded file
    private String fileUrl; // URL or path of the uploaded file
    private String grade; // Stores the grade for the assignment
    private String feedback; // Stores feedback for the assignment
    private boolean graded; // To check if the assignment has been graded or not
    private boolean submitted; // To track whether the student has submitted the assignment

    // Default constructor
    public Assignment(){}

    // Constructor with parameters
    public Assignment(int id, int studentId, String fileName, String fileUrl, boolean graded, boolean submitted){
        this.id = id;
        this.studentId = studentId;
        this.fileName = fileName;
        this.fileUrl = fileUrl;
        this.grade = "Not Graded"; // default value ^^
        this.feedback = ""; // default value ^^
        this.graded = graded;
        this.submitted = submitted;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getFeedback() {
        return feedback;
    }

    public boolean isGraded() {
        return graded;
    }

    public void setGraded(boolean graded) {
        this.graded = graded;
    }

    public boolean isSubmitted() {
        return submitted;
    }

    public void setSubmitted(boolean submitted) {
        this.submitted = submitted;
    }

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }
}
