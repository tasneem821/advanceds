package org.os.lms.service;
import org.os.lms.api.model.Student;
import java.util.List;

public interface StudentService {
    boolean addStudent(Student student);
    Student getStudent(int id);
    List<Student> getAllStudents();
    boolean updateStudentQuizScore(int studentId, int score);
    boolean addAssignmentToStudent(int studentId, int assignmentId);
}