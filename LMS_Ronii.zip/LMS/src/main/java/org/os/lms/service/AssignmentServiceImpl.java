package org.os.lms.service;

import org.os.lms.api.model.Assignment;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class AssignmentServiceImpl implements AssignmentService {

    private final List<Assignment> assignments = new ArrayList<>();
    private int assignmentCounter = 1; // Auto-increment ID for assignments
//
//    // Constructor to manually add assignments
//    public AssignmentServiceImpl() {
//        // Manually adding 7 assignments
//        assignments.add(new Assignment(assignmentCounter++, 101, "Assignment1.pdf", "uploads/assignments/Assignment1.pdf"));
//        assignments.add(new Assignment(assignmentCounter++, 102, "Assignment2.pdf", "uploads/assignments/Assignment2.pdf"));
//        assignments.add(new Assignment(assignmentCounter++, 103, "Assignment3.docx", "uploads/assignments/Assignment3.docx"));
//        assignments.add(new Assignment(assignmentCounter++, 104, "Assignment4.txt", "uploads/assignments/Assignment4.txt"));
//        assignments.add(new Assignment(assignmentCounter++, 105, "Assignment5.xlsx", "uploads/assignments/Assignment5.xlsx"));
//        assignments.add(new Assignment(assignmentCounter++, 106, "Assignment6.pptx", "uploads/assignments/Assignment6.pptx"));
//        assignments.add(new Assignment(assignmentCounter++, 107, "Assignment7.jpg", "uploads/assignments/Assignment7.jpg"));
//    }
//
    @Override
    public boolean submitAssignment(int studentId, MultipartFile file) {
        if (file == null || file.isEmpty()) {
            System.out.println("File is empty or null");
            return false; // Invalid file
        }

        // Define the upload directory
        String uploadDir = System.getProperty("user.dir") + "/uploads/assignments/";
        System.out.println("Upload directory: " + uploadDir);
        File uploadPath = new File(uploadDir);


        // Ensure the directory exists
        if (!uploadPath.exists()) {
            boolean created = uploadPath.mkdirs();
            System.out.println("Directory created: " + created);
        }

        try {
            // Save the file
            String fileName = file.getOriginalFilename();
            String filePath = uploadDir + fileName;
            System.out.println("Saving file to: " + filePath);

            file.transferTo(new File(filePath)); // Save file to the specified path

            // Add assignment to the list
            assignments.add(new Assignment(assignmentCounter++, studentId, fileName, filePath, false, true));
            System.out.println("File saved successfully: " + fileName);
            return true;

        } catch (IOException e) {
            System.out.println("Error saving file: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public Assignment getAssignmentById(int id) {
        return assignments.stream()
                .filter(assignment -> assignment.getId() == id)
                .findFirst()
                .orElse(null);
    }

    @Override
    public List<Assignment> getAssignmentsByStudent(int studentId) {
        List<Assignment> studentAssignments = new ArrayList<>();
        for (Assignment assignment : assignments) {
            if (assignment.getStudentId() == studentId) {
                studentAssignments.add(assignment);
            }
        }
        return studentAssignments;
    }

    @Override
    public boolean gradeAssignment(int assignmentId, String grade, String feedback){
        Assignment assignment = getAssignmentById(assignmentId);
        if(assignment !=null){
            assignment.setGrade(grade);
            assignment.setFeedback(feedback);
            assignment.setGraded(true);
            return true;
        }
        return false;
    }
    @Override
    public String getFeedback(int assignmentId){
        Assignment assignment = getAssignmentById(assignmentId);
        if (assignment != null){
            return "Grade: "+assignment.getGrade()+" | Feedback: "+assignment.getFeedback();
        }
        return "Assignment not found.";
    }

    @Override
    public String trackStudentProgress(int studentId){
        List<Assignment> studentAssignments = getAssignmentsByStudent(studentId);
        int totalAssignments = studentAssignments.size();
        int submittedCounts = 0;
        int gradedCounts = 0;
        int feedbackCounts = 0;
        for(Assignment assignment : studentAssignments){
            if(assignment.isSubmitted()){
                submittedCounts++;
            }
            if(assignment.isGraded()){
                gradedCounts++;
            }
            if(assignment.getFeedback() != null && !assignment.getFeedback().isEmpty()){
                feedbackCounts++;
            }
        }
        return String.format("Student %d -> Total Assignments: %d, Submitted: %d, Graded: %d, Feedback Given: %d",
                studentId, totalAssignments, submittedCounts, gradedCounts, feedbackCounts);
    }
}
