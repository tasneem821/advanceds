package org.os.lms.service;
import org.os.lms.api.model.Student;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class StudentServiceImpl implements StudentService {

    private final List<Student> students = new ArrayList<>();

    @Override
    public boolean addStudent(Student student) {
        for (Student existingStudent : students) {
            if (existingStudent.getId() == student.getId()) {
                return false; // Duplicate ID
            }
        }
        return students.add(student);
    }

    @Override
    public Student getStudent(int id) {
        return students.stream()
                .filter(student -> student.getId() == id)
                .findFirst()
                .orElse(null);
    }

    @Override
    public List<Student> getAllStudents() {
        return new ArrayList<>(students);
    }

    @Override
    public boolean updateStudentQuizScore(int studentId, int score) {
        Student student = getStudent(studentId);
        if (student == null) {
            return false; // Student not found
        }
        student.getQuizScores().add(score);
        return true;
    }

    @Override
    public boolean addAssignmentToStudent(int studentId, int assignmentId) {
        Student student = getStudent(studentId);
        if (student == null) {
            return false; // Student not found
        }
        student.getAssignmentIds().add(assignmentId);
        return true;
    }
}
