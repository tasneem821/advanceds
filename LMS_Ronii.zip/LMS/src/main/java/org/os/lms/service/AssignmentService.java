package org.os.lms.service;

import org.os.lms.api.model.Assignment;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface AssignmentService {
    boolean submitAssignment(int studentId, MultipartFile file); // Submit an assignment
    Assignment getAssignmentById(int id); // Get an assignment by its ID
    List<Assignment> getAssignmentsByStudent(int studentId); // Get all assignments by a student
    boolean gradeAssignment(int assignmentId, String grade, String feedback);
    String getFeedback(int assignmentId); // Retrieve feedback for an assignment
    String trackStudentProgress(int studentId); // Track student's assignment progress


}
