package org.os.lms.api.controller;

import org.os.lms.api.model.Assignment;
import org.os.lms.api.model.Response;
import org.os.lms.service.AssignmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/assignments")
public class AssignmentController {

    @Autowired
    private AssignmentService assignmentService;

    AssignmentController(AssignmentService assignmentService){
        this.assignmentService = assignmentService;
    }

    @PostMapping("")
    public Response submitAssignment(@RequestParam int studentId, @RequestParam MultipartFile file) {
        boolean result = assignmentService.submitAssignment(studentId, file);
        Response response = new Response();
        response.setStatus(result);
        response.setMessage(result ? "Assignment submitted successfully" : "Failed to submit assignment");
        return response;
    }


    @GetMapping("/{id}")
    public Assignment getAssignmentById(@PathVariable int id){
        return assignmentService.getAssignmentById(id);
    }

    @GetMapping("/student/{studentId}")
    public List<Assignment> getAssignmentByStudent(@PathVariable int studentId){
        return assignmentService.getAssignmentsByStudent(studentId);
    }

    @PostMapping("/{assignmentId}/grade")
    public  Response gradeAssignment(@PathVariable int assignmentId,@RequestParam String grade,@RequestParam String feedback){
        boolean result = assignmentService.gradeAssignment(assignmentId, grade, feedback);
        Response response = new Response();
        response.setStatus(result);
        response.setMessage(result? "Assignment graded successfully":"Failed to grade assignment");
        return response;
    }
    @GetMapping("/{assignmentId}/feedback")
    public Response getFeedback(@PathVariable int assignmentId){
        String feedback = assignmentService.getFeedback(assignmentId);
        Response response = new Response();
        response.setStatus(true);
        response.setMessage(feedback);
        return response;
    }
    @GetMapping("/student/{studentId}/progress")
    public Response trackStudentProgress(@PathVariable int studentId){
        String progress = assignmentService.trackStudentProgress(studentId);
        Response response = new Response();
        response.setStatus(true);
        response.setMessage(progress);
        return response;
    }
}
