package org.os.lms.api.model;
import java.util.Objects;
import java.util.List;

public class Student {
    private int id;
    private String name;
    private List<Integer> quizScores;
    private List<Integer> assignmentIds;


    public Student(int id, String name, List<Integer> quizScores, List<Integer> assignmentIds) {
        this.id = id;
        this.name = name;
        this.quizScores = quizScores;
        this.assignmentIds = assignmentIds;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Integer> getQuizScores() {
        return quizScores;
    }

    public void setQuizScores(List<Integer> quizScores) {
        this.quizScores = quizScores;
    }

    public List<Integer> getAssignmentIds() {
        return assignmentIds;
    }

    public void setAssignmentIds(List<Integer> assignmentIds) {
        this.assignmentIds = assignmentIds;
    }

    @Override
    public String toString() {
        return "Student{id=" + id + ", name='" + name + "', quizScores=" + quizScores + ", assignmentIds=" + assignmentIds + "}";
    }

    // equals() method
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Student student = (Student) o;
        return id == student.id &&
                name.equals(student.name) &&
                quizScores.equals(student.quizScores) &&
                assignmentIds.equals(student.assignmentIds);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, quizScores, assignmentIds);
    }
}
