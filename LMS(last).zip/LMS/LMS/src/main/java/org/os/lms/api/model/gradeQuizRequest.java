package org.os.lms.api.model;

import java.util.Map;

public class gradeQuizRequest {
    private int id; // Student ID
    private String name; // Student Name
    private Map<Integer, String> answers; // Map of Question ID to Answer

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Map<Integer, String> getAnswers() {
        return answers;
    }

    public void setAnswers(Map<Integer, String> answers) {
        this.answers = answers;
    }
}
