package org.os.lms.api.model;
import java.util.List;

public class Quiz {
    private int id;
    private String title;
    private int courseId; // ID of the course to which this quiz belongs
    private List<Question> questions; // List of questions in the quiz
    public Quiz(int id, String title, int courseId ) {
        this.id = id;
        this.title = title;
        this.courseId = courseId;
    }
    public Quiz(){}
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public List<Question> getQuestions() {
        return questions;
    }

    public void setQuestions(List<Question> questions) {
        this.questions = questions;
    }
}

