package org.os.lms.service;

import org.os.lms.api.model.Student;
import org.springframework.stereotype.Service;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Service
public class StudentServiceImpl implements StudentService {

    private final List<Student> students = new ArrayList<>();

    public StudentServiceImpl() {

        students.add(new Student("user1", "pass1", "Student", 1, "Nada Mohammed",
                Map.of(1, 100, 2, 90), List.of(201, 202)));
        students.add(new Student("user2", "pass2", "Student", 2, "Nada Assad",
                Map.of(101, 78, 102, 88), List.of(203)));
        students.add(new Student("user3", "pass3", "Student", 3, "Nour Ahmed",
                Map.of(101, 92, 102, 95), List.of(204, 205)));
        students.add(new Student("user4", "pass4", "Student", 4, "Rana",
                Map.of(101, 70, 102, 75), List.of(206)));
        students.add(new Student("user5", "pass5", "Student", 5, "Roqaia",
                Map.of(101, 88, 102, 91), List.of(207, 208)));
        students.add(new Student("user6", "pass6", "Student", 6, "Reem",
                Map.of(101, 65, 102, 70), List.of(209)));
        students.add(new Student("user7", "pass7", "Student", 7, "Amira",
                Map.of(101, 95, 102, 97), List.of(210, 211)));
        students.add(new Student("user8", "pass8", "Student", 8, "Israa",
                Map.of(101, 80, 102, 85), List.of(212)));
        students.add(new Student("user9", "pass9", "Student", 9, "Mariam",
                Map.of(101, 75, 102, 78), List.of(213, 214)));
        students.add(new Student("user10", "pass10", "Student", 10, "Ahmed",
                Map.of(101, 89, 102, 93), List.of(215)));
    }

    @Override
    public boolean addStudent(Student student) {
        for (Student existingStudent : students) {
            if (existingStudent.getId() == student.getId()) {
                return false; // Duplicate ID
            }
        }
        return students.add(student);
    }

    @Override
    public Student getStudent(int id) {
        return students.stream()
                .filter(student -> student.getId() == id)
                .findFirst()
                .orElse(null);
    }

    @Override
    public List<Student> getAllStudents() {
        return new ArrayList<>(students);
    }

    @Override
    public void updateStudentQuizScore(int studentId, int quizId, int score) {
        Student student = getStudent(studentId);
        if (student == null) {
            return ; // Student not found
        }
        student.getQuizScores().put(quizId, score);

    }

    @Override
    public boolean addAssignmentToStudent(int studentId, int assignmentId) {
        Student student = getStudent(studentId);
        if (student == null) {
            return false; // Student not found
        }
        student.getAssignmentIds().add(assignmentId);
        return true;
    }

}
