package org.os.lms.api.controller;

public class AssignmentController {
}
