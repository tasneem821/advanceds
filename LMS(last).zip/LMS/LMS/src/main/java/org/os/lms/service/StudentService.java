package org.os.lms.service;

import org.os.lms.api.model.Student;
import java.util.List;

public interface StudentService {
    boolean addStudent(Student student); // Add a new student
    Student getStudent(int id); // Get student by ID
    List<Student> getAllStudents(); // Get all students
    void updateStudentQuizScore(int studentId, int quizId, int score); // Update student's quiz score
    boolean addAssignmentToStudent(int studentId, int assignmentId); // Add assignment to student
    //void addScore(int quizId, int score);
}
