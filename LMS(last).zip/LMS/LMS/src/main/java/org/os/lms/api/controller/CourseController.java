package org.os.lms.api.controller;

import org.os.lms.api.model.Course;
import org.os.lms.service.CourseService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/courses")
public class CourseController {
    private final CourseService courseService;

    public CourseController(CourseService courseService) {
        this.courseService = courseService;
    }
    @PostMapping("/create")
    public ResponseEntity<String> createCourse(@RequestBody Course course) {
        courseService.addCourse(course);
        return ResponseEntity.ok("Course created successfully");
    }


}

