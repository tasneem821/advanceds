package org.os.lms.api.model;
public class Admin extends User {

    public Admin(String userName,String password, String role) {
        super(userName, password,"Admin");
        
        
    }

}