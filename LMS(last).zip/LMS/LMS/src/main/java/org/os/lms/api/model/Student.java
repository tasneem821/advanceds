package org.os.lms.api.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class Student extends User {

    private int id;
    private String name;
    private Map<Integer, Integer> quizScores = new HashMap<>(); // Map of quizId to scores
    private List<Integer> assignmentIds;

    public Student(String userName,String password, String role ,int id, String name, Map<Integer, Integer> quizScores, List<Integer> assignmentIds) {
        super(userName, password,"Student");
        this.id = id;
        this.name = name;
        this.quizScores = quizScores;
        this.assignmentIds = assignmentIds;
        
    }



    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public Map<Integer, Integer> getQuizScores() {
        return quizScores;
    }

    public void setQuizScores(Map<Integer, Integer> quizScores) {
        this.quizScores = quizScores;
    }

    public List<Integer> getAssignmentIds() {
        return assignmentIds;
    }

    public void setAssignmentIds(List<Integer> assignmentIds) {
        this.assignmentIds = assignmentIds;
    }

    @Override
    public String toString() {
        return "Student{id=" + id + ", name='" + name + "', quizScores=" + quizScores + ", assignmentIds=" + assignmentIds + "}";
    }

    // equals() method
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Student student = (Student) o;
        return id == student.id &&
                name.equals(student.name) &&
                quizScores.equals(student.quizScores) &&
                assignmentIds.equals(student.assignmentIds);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, quizScores, assignmentIds);
    }
}
