package org.os.lms.api.controller;
import org.os.lms.api.model.User;
import org.os.lms.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/profile")
public class ProfileController {

    @Autowired
    private UserService userService;

    @GetMapping("/{username}")
    public ResponseEntity<String> viewProfile(@PathVariable String username, Authentication authentication) {
        // Automatically check authentication via Spring Security
        if (authentication == null || !authentication.isAuthenticated()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Access Denied: Please log in");
        }

        // Proceed with normal logic, assuming the user is authenticated
        return ResponseEntity.ok("Profile for user: " + username);
    }

    @PutMapping("/update/{username}")
    public ResponseEntity<String> updateProfile(@PathVariable String username, @RequestBody User updatedUser) {
        User existingUser = userService.getUserByUsername(username);
        if (existingUser == null) {
            return ResponseEntity.status(404).body("User not found");
        }
        existingUser.setPassword(updatedUser.getPassword());
        existingUser.setRole(updatedUser.getRole());
        return ResponseEntity.ok("Profile updated successfully");
    }
}

