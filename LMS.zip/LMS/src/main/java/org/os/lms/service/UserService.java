package org.os.lms.service;
import java.util.HashMap;
import java.util.Map;

import org.os.lms.api.model.User;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    private final Map<String, User> users = new HashMap<>();
    private BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();


    public UserService(){

        users.put("admin", new User("admin", encoder.encode("admin123"), "ROLE_ADMIN"));
        users.put("instructor", new User("instructor", encoder.encode("instructor123"), "ROLE_INSTRUCTOR"));
        users.put("student", new User("student", encoder.encode("student123"), "ROLE_STUDENT"));

    }

    public User getUserByUserName(String userName){
        return users.get(userName);
    }
    public User getUserByUsername(String username) {
        System.out.println("Looking up user: " + username);
        return users.get(username);
    }
    public boolean authenticate(String username, String password) {
        User user = getUserByUserName(username);
        if (user == null) {
            return false;
        }
        return encoder.matches(password, user.getPassword());
    }
    public void addUser(User user){
        users.put(user.getUserName(),user);
    }

}
