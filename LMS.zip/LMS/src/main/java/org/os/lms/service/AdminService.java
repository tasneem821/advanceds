package org.os.lms.service;

import java.util.ArrayList;
import java.util.List;

import org.os.lms.api.model.User;
import org.springframework.stereotype.Service;

@Service
public class AdminService {
    private final List<User> users = new ArrayList<>();

    public void createUser(User user) {
        users.add(user);
    }

    public List<User> getAllUsers() {
        return users;
    }

    public void deactivateUser(String userName) {
        User user = users.stream()
                    .filter(u -> u.getUserName().equals(userName))
                        .findFirst()
                        .orElseThrow(() -> new RuntimeException("User not found"));
        user.setActive(false);
    }

}

