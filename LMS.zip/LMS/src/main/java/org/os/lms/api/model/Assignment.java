package org.os.lms.api.model;

public class Assignment {
}
