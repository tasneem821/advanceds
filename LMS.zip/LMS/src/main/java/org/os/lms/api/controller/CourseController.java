package org.os.lms.api.controller;

import java.util.List;

import org.os.lms.api.model.Course;
import org.os.lms.api.model.User;
import org.os.lms.service.CourseService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/courses")
public class CourseController {
    private final CourseService courseService;

    public CourseController(CourseService courseService) {
        this.courseService = courseService;
    }

    @PostMapping
    public ResponseEntity<String> createCourse(@RequestBody Course course) {
        courseService.addCourse(course);
        return ResponseEntity.ok("Course created successfully");
    }

    @PostMapping("/{courseId}/add-student/{studentUserName}")
    public ResponseEntity<String> addStudentToCourse(@PathVariable String studentUserName, @PathVariable int courseId) {
        courseService.enrollStudentInCourse(studentUserName, courseId);
        return ResponseEntity.ok("Student added to course successfully");
    }

    @GetMapping("/{courseId}/students")
    public ResponseEntity<List<User>> viewCourseStudents(@PathVariable int courseId) {
        return ResponseEntity.ok(courseService.getStudentsInCourse(courseId));
    }
}

