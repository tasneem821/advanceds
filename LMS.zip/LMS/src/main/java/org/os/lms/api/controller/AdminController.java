package org.os.lms.api.controller;

import java.util.List;

import org.os.lms.api.model.User;
import org.os.lms.service.AdminService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/admin")
public class AdminController {
    private final AdminService adminService;

    public AdminController(AdminService adminService) {
        this.adminService = adminService;
    }

    @PostMapping("/create-user")
    public ResponseEntity<String> createUser(@RequestBody User user) {
        adminService.createUser(user);
        return ResponseEntity.ok("User created successfully");
    }

    @GetMapping("/view-users")
    public ResponseEntity<List<User>> viewUsers() {
        return ResponseEntity.ok(adminService.getAllUsers());
    }

    @PostMapping("/deactivate-user/{userName}")
    public ResponseEntity<String> deactivateUser(@PathVariable String userName) {
        adminService.deactivateUser(userName);
        return ResponseEntity.ok("User deactivated successfully");
    }
}
