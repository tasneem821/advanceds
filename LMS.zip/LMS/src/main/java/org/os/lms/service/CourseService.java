package org.os.lms.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.os.lms.api.model.Course;
import org.os.lms.api.model.User;
import org.springframework.stereotype.Service;

@Service
public class CourseService {
    private final List<Course> courses = new ArrayList<>();
    private final List<User> users = new ArrayList<>();
    private final Map<String, List<Course>> studentCourses = new HashMap<>();

    // Add a new course
    public void addCourse(Course course) {
        courses.add(course);
    }

    // Enroll a student in a course
    public void enrollStudentInCourse(String studentUserName, int courseId) {
            // Find the course
            Course course = courses.stream()
                    .filter(c -> c.getCourseId() == courseId)
                    .findFirst()
                    .orElseThrow(() -> new RuntimeException("Course not found"));
        
            // Directly check if the student exists and enroll them
            boolean studentFound = users.stream()
                    .anyMatch(u -> u.getUserName().equals(studentUserName) && "Student".equals(u.getRole()));
            
            if (!studentFound) {
                throw new RuntimeException("Student not found");
            }
        
            // Enroll student if they are not already enrolled
            studentCourses.putIfAbsent(studentUserName, new ArrayList<>());
            List<Course> enrolledCourses = studentCourses.get(studentUserName);
            if (!enrolledCourses.contains(course)) {
                enrolledCourses.add(course);
            } else {
                throw new RuntimeException("Student already enrolled in this course");
            }
        
        
    }

    // Unenroll a student from a course
    public void unenrollStudentFromCourse(String studentUserName, int courseId) {
        if (studentCourses.containsKey(studentUserName)) {
            studentCourses.get(studentUserName).removeIf(course -> course.getCourseId() == courseId);
        } else {
            throw new RuntimeException("Student not enrolled in any courses");
        }
    }

    // View courses a student is enrolled in
    public List<Course> getEnrolledCourses(String studentUserName) {
        return studentCourses.getOrDefault(studentUserName, new ArrayList<>());
    }

    // Get all students in a course
    public List<User> getStudentsInCourse(int courseId) {
        Course course = courses.stream()
                .filter(c -> c.getCourseId() == courseId)
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Course not found"));

        List<User> enrolledStudents = new ArrayList<>();
        studentCourses.forEach((userName, enrolledCourses) -> {
            if (enrolledCourses.contains(course)) {
                enrolledStudents.add(users.stream()
                        .filter(u -> u.getUserName().equals(userName))
                        .findFirst()
                        .orElse(null));
            }
        });
        return enrolledStudents;
    }
}
