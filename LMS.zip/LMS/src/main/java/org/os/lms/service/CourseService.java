package org.os.lms.service;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.os.lms.api.model.Course;
import org.os.lms.api.model.Student;
import org.os.lms.api.model.User;
import org.springframework.stereotype.Service;

@Service
public class CourseService {
    private final List<Course> courses = new ArrayList<>();
    private final List<Student> students = new ArrayList<>();
    private final Map<String, List<Course>> studentCourses = new HashMap<>();


    public void addCourse(Course course) {
        courses.add(course);
    }

    public void enrollStudentInCourse(String studentUserName, int courseId) {
            // Find the course
            Course course = courses.stream()
                    .filter(c -> c.getCourseId() == courseId)
                    .findFirst()
                    .orElseThrow(() -> new RuntimeException("Course not found"));
        
    
            boolean studentFound = students.stream()
                    .anyMatch(u -> u.getUserName().equals(studentUserName) && "Student".equals(u.getRole()));
            
            if (!studentFound) {
                throw new RuntimeException("Student not found");
            }
        
    
            studentCourses.putIfAbsent(studentUserName, new ArrayList<>());
            List<Course> enrolledCourses = studentCourses.get(studentUserName);
            if (!enrolledCourses.contains(course)) {
                enrolledCourses.add(course);
            } else {
                throw new RuntimeException("Student already enrolled in this course");
            }
        
        
    }


    public void unenrollStudentFromCourse(String studentUserName, int courseId) {
        if (studentCourses.containsKey(studentUserName)) {
            studentCourses.get(studentUserName).removeIf(course -> course.getCourseId() == courseId);
        } else {
            throw new RuntimeException("Student not enrolled in any courses");
        }
    }

    public List<Course> getEnrolledCourses(String studentUserName) {
        return studentCourses.getOrDefault(studentUserName, new ArrayList<>());
    }

    public List<User> getStudentsInCourse(int courseId) {
        Course course = courses.stream()
                .filter(c -> c.getCourseId() == courseId)
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Course not found"));

        List<User> enrolledStudents = new ArrayList<>();
        studentCourses.forEach((userName, enrolledCourses) -> {
            if (enrolledCourses.contains(course)) {
                enrolledStudents.add(students.stream()
                        .filter(u -> u.getUserName().equals(userName))
                        .findFirst()
                        .orElse(null));
            }
        });
        return enrolledStudents;
    }
}
