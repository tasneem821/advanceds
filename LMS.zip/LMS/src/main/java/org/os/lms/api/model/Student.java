package org.os.lms.api.model;

public class Student extends User {
    public Student(String userName,String password, String role) {
        super(userName, password,"Student");
        
        
    }
}
