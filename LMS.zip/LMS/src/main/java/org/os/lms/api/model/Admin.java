package org.os.lms.api.model;

import java.util.ArrayList;
import java.util.List;

public class Admin {
    private final List<User> users = new ArrayList<>();//store users in array

    public void createUser(String useName, String password, String role) {
        User newUser = new User(useName, password, role);
        users.add(newUser);
    }

    public void viewUsers() {
        users.forEach(System.out::println);
    }

    public void updateUserRole( String userName, String newRole) {
        users.stream().filter(user -> user.getUserName().equals(userName)).findFirst()
            .ifPresent(user -> user.setRole(newRole));
    }

    public void setUserStatus(String userName, boolean isActive) {
        users.stream().filter(user -> user.getUserName().equals(userName)).findFirst()
            .ifPresent(user -> user.setActive(isActive));
    }
}
