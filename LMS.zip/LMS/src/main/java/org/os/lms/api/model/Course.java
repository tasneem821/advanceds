package org.os.lms.api.model;

import java.util.ArrayList;
import java.util.List;

public class Course {
    private int courseId;
    private String courseName;
    private List<User> students = new ArrayList<>();//students enrolled in specific course

    public Course(int courseId, String courseName) {
        this.courseId = courseId;
        this.courseName = courseName;
    }

// course related features for admin
    public void addStudent(User student) {
        if (!students.contains(student)) {
            students.add(student);
        } else {
            System.out.println("Student already enrolled.");
        }
    }

    public void removeStudent(String userName) {
        students.removeIf(student -> student.getUserName().equals(userName));
    }

    public void viewStudents() {
        students.forEach(System.out::println);
    }

    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public void setStudents(List<User> students) {
        this.students = students;
    }

}
