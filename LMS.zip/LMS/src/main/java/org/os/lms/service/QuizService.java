package org.os.lms.service;

public interface QuizService {
}
